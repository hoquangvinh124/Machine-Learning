from flask import Flask, render_template, request, jsonify
from FileUtil import FileUtil

app = Flask(__name__)

# Load the trained model at startup
trainedModel = FileUtil.loadmodel("housingmodel.zip")


@app.route("/")
def main():
    return render_template("index.html")


@app.route("/doprediction", methods=["POST"])
def doPrediction():
    # Get JSON data from request
    data = request.get_json()

    area_income_value = float(data["area_income"])
    area_house_age_value = float(data["area_house_age"])
    area_number_of_rooms_value = float(data["area_number_of_rooms"])
    area_number_of_bedrooms_value = float(data["area_number_of_bedrooms"])
    area_population_value = float(data["area_population"])

    result = trainedModel.predict([[area_income_value,
                                    area_house_age_value,
                                    area_number_of_rooms_value,
                                    area_number_of_bedrooms_value,
                                    area_population_value]])

    return jsonify({"prediction": float(result[0])})


if __name__ == "__main__":
    app.run(host="localhost", port=5000, debug=True)
